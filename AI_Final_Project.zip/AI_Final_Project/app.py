from flask import Flask, request, jsonify, render_template
import pickle
import numpy as np

# Lazy model loader: don't crash if the pickle isn't present at import time
model = None

def load_model():
    global model
    if model is None:
        try:
            with open("best_model.pkl", "rb") as f:
                model = pickle.load(f)
        except Exception:
            model = None
    return model

app = Flask(__name__)

@app.route("/")
def home():
    # Serve the HTML page from templates; CSS/JS are served from static/
    return render_template("index.html")


@app.route("/predict", methods=["POST"])
def predict():
    try:
        # Support both JSON API calls and traditional HTML form posts
        if request.is_json:
            data = request.get_json()
        else:
            data = request.form.to_dict()

        # Required fields
        required = ["Temperature", "Humidity", "Wind_Speed", "Cloud_Cover", "Pressure"]
        for key in required:
            if key not in data or data.get(key) == "":
                msg = f"Missing field: {key}"
                if request.is_json:
                    return jsonify({"error": msg}), 400
                return render_template("index.html", prediction=msg), 400

        # Parse values
        Temperature = float(data["Temperature"])
        Humidity = float(data["Humidity"])
        Wind_Speed = float(data["Wind_Speed"])
        Cloud_Cover = float(data["Cloud_Cover"])
        Pressure = float(data["Pressure"])

        features = np.array([[Temperature, Humidity, Wind_Speed, Cloud_Cover, Pressure]])

        mdl = load_model()
        if mdl is None:
            msg = "Model not found (best_model.pkl). Place the trained model in the project root."
            if request.is_json:
                return jsonify({"error": msg}), 500
            return render_template("index.html", prediction=msg), 500

        prediction = mdl.predict(features)
        result = str(prediction[0])

        if request.is_json:
            return jsonify({"Prediction": result})
        return render_template("index.html", prediction=result)

    except Exception as e:
        if request.is_json:
            return jsonify({"error": str(e)}), 400
        return render_template("index.html", prediction=f"Error: {e}"), 400


if __name__ == "__main__":
    app.run(debug=True)
